import 'package:flutter/material.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey,
        title: Center(
          child: Text('Profil', style: TextStyle(fontSize: 24),)
        ),
      ),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(image: DecorationImage(image: AssetImage('assets/images/posters/the_mask.jpg'))),
          // child: Image(image: AssetImage('assets/images/posters/the_mask.jpg'),)
        ),
      )
    );
  }
}
  